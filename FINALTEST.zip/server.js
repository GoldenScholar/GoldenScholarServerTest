var express = require('express');
var app = express();
var passport   = require('passport');
var session    = require('express-session');
var bodyParser = require('body-parser');
var env = require('dotenv').load();
var exphbs = require('express-handlebars');

//For BodyParser
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// For Passport
 
app.use(session({ secret: 'keyboard cat',name: 'cookie_name', proxy: true,resave: true, saveUninitialized:true})); // session secret
 
app.use(passport.initialize());
 
app.use(passport.session()); // persistent login sessions

//Models
var models = require(__dirname +  "/app/models");
 
 //Routes
var authRoute = require(__dirname + '/app/routes/auth.js')(app,passport, models.lecture, models.groups);

//load passport strategies
require(__dirname +  '/app/config/passport/passport.js')(passport, models.users, models.lecture);
 
//Sync Database
models.sequelize.sync().then(function() {
 
    console.log('Nice! Database looks fine')
 
}).catch(function(err) {
 
    console.log(err, "Something went wrong with the Database Update!")
 
});

//For Handlebars
app.set('views', __dirname + '/app/views')
app.use(express.static(__dirname + '/public'));
app.engine('hbs', exphbs({
    extname: '.hbs'
}));
app.set('view engine', '.hbs');

app.get('/', function(req, res){
  res.render('loginHub.hbs', {
        title: 'loginHub',
    nav: ['loginHub', 'loginStudent', 'loginFaculty', 'registerStudent', 'registerFaculty', 'tempProfile']
  });
});

app.listen(8081, function(err) {
 
    if (!err)
        console.log("Site is live");
    else console.log(err)
 
});