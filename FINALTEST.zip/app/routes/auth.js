var authController = require('../controllers/authcontroller.js');
var Lecture = require('../models/index');
 
 
module.exports = function(app, passport, lecture, group) {
 
    app.get('/signupstu', authController.signupstu);
 
	app.get('/signupfac', authController.signupfac);
 
    app.get('/signinstu', authController.signinstu);
	
	app.get('/signinfac', authController.signinfac);
	
	app.get('/resetPass', authController.resetPass);
	
	app.get('/invalidPage', authController.invalidPage);
 
	app.get('/dashboard',isLoggedIn, authController.dashboard);
	
	app.get('/studentHub',isLoggedIn, authController.studentHub);
	
	app.get('/facultyHub',isLoggedIn, function(req, res) {res.render('facultyHub', { user: req.user });});
	
	app.get('/createLecture',isLoggedIn, authController.createLecture);
	
	app.get('/viewMyLectures',isLoggedIn, authController.viewMyLectures);
	
	app.get('/createGroup',isLoggedIn, authController.createGroup);
	
	app.get('/deleteGroup',isLoggedIn, authController.deleteGroup);
	
	app.get('/joinGroup',isLoggedIn, authController.joinGroup);
	
	app.get('/viewProfile',isLoggedIn, function(req, res) {res.render('viewProfile', { user: req.user });});
	
	app.get('/logout',authController.logout);
	
	app.post('/signupstu', passport.authenticate('local-stu-signup', {
            successRedirect: '/signinstu',
 
            failureRedirect: '/signupstu'
        }
 
    ));
	
	app.post('/createGroup',function(req, res){
		var newGroup = {
            facultyName: req.user.username,
			className: req.body.className,
			classNumber: req.body.classNum,
			description: req.body.descrip,
			}
			group.create(newGroup);	
        res.location('/facultyHub');
		res.redirect('/facultyHub');
	});
	
	app.post('/createLecture',function(req, res){
		var newLecture;
		var count = req.body.count;
		
			console.log(count);
			newLecture = {
            facultyName: req.user.username,
			topicName: req.body.tName,
			subTopicName: req.body.subName0,
			subTopicInfo: req.body.subInfo0,
			}
			lecture.create(newLecture);	
		if(count > 2){
			newLecture = {
            facultyName: req.user.username,
			topicName: req.body.tName,
			subTopicName: req.body.subName1,
			subTopicInfo: req.body.subInfo1,
			}
			lecture.create(newLecture);	
		}
		if(count > 3){
			newLecture = {
            facultyName: req.user.username,
			topicName: req.body.tName,
			subTopicName: req.body.subName2,
			subTopicInfo: req.body.subInfo2,
			}
			lecture.create(newLecture);	
		}
		if(count > 4){
			newLecture = {
            facultyName: req.user.username,
			topicName: req.body.tName,
			subTopicName: req.body.subName3,
			subTopicInfo: req.body.subInfo3,
			}
			lecture.create(newLecture);	
		}
		if(count > 5){
			newLecture = {
            facultyName: req.user.username,
			topicName: req.body.tName,
			subTopicName: req.body.subName4,
			subTopicInfo: req.body.subInfo4,
			}
			lecture.create(newLecture);	
		}
		if(count > 6){
			newLecture = {
            facultyName: req.user.username,
			topicName: req.body.tName,
			subTopicName: req.body.subName5,
			subTopicInfo: req.body.subInfo5,
			}
			lecture.create(newLecture);	
		}
		res.location('/facultyHub');
		res.redirect('/facultyHub');
	});
	
    /*app.post('/createLecture', passport.authenticate('create-lecture', {
            successRedirect: '/createLecture',
 
            failureRedirect: '/facultyHub'
        }
 
    ));*/
	
	app.post('/signupfac', passport.authenticate('local-fac-signup', {
            successRedirect: '/signinfac',
 
            failureRedirect: '/signupfac'
        }
 
    ));
	
	app.post('/resetPass', passport.authenticate('forgot-pass', {
            successRedirect: '/',
 
            failureRedirect: '/resetPass'
        }
 
    ));
	
	app.post('/signinstu', passport.authenticate('local-stu-signin', {
			successRedirect: '/studentHub',
 
			failureRedirect: '/signinstu'
		}
 
	));
	
	app.post('/signinfac', passport.authenticate('local-fac-signin', {
			successRedirect: '/facultyHub',
 
			failureRedirect: '/signinfac'
		}
 
	));
 
	function isLoggedIn(req, res, next) {
 
		if (req.isAuthenticated())
     
			return next();
         
		res.redirect('/invalidPage');
 
	}
 
}